document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault();

    // Get elements safely
    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let phone = document.getElementById("phone").value;
    let email = document.getElementById("email").value;
    let address = document.getElementById("address").value;
    let pincode = document.getElementById("pincode").value;
    let password = document.getElementById("password").value;

    let user = {
        name, age, phone, email, address, pincode, password
    };

    localStorage.setItem("userData", JSON.stringify(user));
    localStorage.setItem("loginPrefill", JSON.stringify({ email, phone }));

    let msg = document.getElementById("msg");
    msg.style.color = "green";
    msg.innerText = "Registration successful! Redirecting to login...";

    setTimeout(() => {
        window.location.href = "login.html";
    }, 1500);
});
