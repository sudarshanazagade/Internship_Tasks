let user = JSON.parse(localStorage.getItem("userData"));

if (!user) {
    window.location.href = "login.html";
}

document.getElementById("userDetails").innerHTML = `
<p><b>Name:</b> ${user.name}</p>
<p><b>Age:</b> ${user.age}</p>
<p><b>Phone:</b> ${user.phone}</p>
<p><b>Email:</b> ${user.email}</p>
<p><b>Address:</b> ${user.address}</p>
<p><b>Pincode:</b> ${user.pincode}</p>
`;

function logout() {
    localStorage.clear();
    window.location.href = "login.html";
}
